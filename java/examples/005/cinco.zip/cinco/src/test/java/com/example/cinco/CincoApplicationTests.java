package com.example.cinco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CincoApplicationTests {

	@Test
	void contextLoads() {
	}

}
