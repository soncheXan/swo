package com.example.cinco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CincoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CincoApplication.class, args);
	}

}
